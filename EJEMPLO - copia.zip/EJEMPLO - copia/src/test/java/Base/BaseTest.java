package Base;

import Pages.HomePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class BaseTest {

    protected WebDriver driver;


    protected HomePage homePage;

    @BeforeMethod
    public void goHome(){
        driver.get("https://www.advantageonlineshopping.com");

        homePage = new HomePage(driver);
    }

    @BeforeClass
    public void setup() {
        System.setProperty("webdriver.chrome.driver","./src/test/resources/chromedriver.exe");
        driver = new ChromeDriver();
        goHome();

        driver.manage().window().maximize();

        // specific width (Show Iphone X emulator)
        //Dimension size = new Dimension(375,812);
        //driver.manage().window().setSize(size);

        //Imprimir titulo pagina
        System.out.print(driver.getTitle());



        //loginPage = new LoginPage(driver);

        //driver.quit();
    }

}
