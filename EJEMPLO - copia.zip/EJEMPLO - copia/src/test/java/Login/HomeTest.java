package Login;

import Base.BaseTest;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import static org.junit.Assert.assertEquals;
import org.testng.Assert;

import static org.testng.Assert.assertEquals;

public class HomeTest extends BaseTest {

    @Test
    public void testBuy() throws InterruptedException {
        //HomeTest homePage = HomePage.clickButtonLogin();


        homePage.clickButton();
        Thread.sleep(4000);
        homePage.clickProduct();
        Thread.sleep(4000);
        homePage.clickAdd();
        Thread.sleep(4000);
        homePage.clickHome();
        Thread.sleep(4000);
        homePage.clickLaptop();
        Thread.sleep(4000);
        homePage.clickProduct2();
        Thread.sleep(4000);
        homePage.clickAdd();
        Thread.sleep(4000);
        homePage.clickcheckOutPopUp();

        System.out.println("The value First product: " + homePage.getPrice1());
        System.out.println("The value of second product: " + homePage.getPrice2());
        Assert.assertEquals(homePage.especifico1(),homePage.getPrice1());
        Assert.assertEquals(homePage.especifico2(),homePage.getPrice2());
        Assert.assertEquals(homePage.getPrice1(), "$299.99");
        Assert.assertEquals(homePage.getPrice2(), "$1,009.00");

        System.out.println("The value First product: " + homePage.getPrice1());
        System.out.println("The value of second product: " + homePage.getPrice2());


    }
}
