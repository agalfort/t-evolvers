package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {


    private WebDriver driver;
    private By tabletsLink = By.id("tabletsTxt");

    private By LaptopLink = By.id("laptopsTxt");
    private By Product1 = By.xpath("/html/body/div[3]/section/article/div[3]/div/div/div[2]/ul/li[1]/p[1]/a");

    private By Product2 = By.xpath("/html/body/div[3]/section/article/div[3]/div/div/div[2]/ul/li[1]");

    private By AddCart = By.name("save_to_cart");

    private By ClickHome1 = By.xpath("/html/body/div[3]/nav/a[1]");

    private By checkOutPopUp = By.id("checkOutPopUp");

    private By Product1Price = By.xpath("(//tr[@id='product']/td[3]/p)[3]");
    private By Product2Price = By.xpath("(//tr[@id='product']/td[3]/p)[4]");




    public HomePage(WebDriver driver)
    {
        this.driver = driver;
    }

    public  void clickButton(){
        driver.findElement(tabletsLink).click();

    }

    public  void clickLaptop(){
        driver.findElement(LaptopLink).click();

    }

    public  void clickProduct(){
        driver.findElement(Product1).click();

    }

    public  void clickProduct2(){
        driver.findElement(Product2).click();

    }

    public  void clickAdd(){
        driver.findElement(AddCart).click();

    }

    public  void clickHome(){
        driver.findElement(ClickHome1).click();

    }

    public  void clickcheckOutPopUp(){
        driver.findElement(checkOutPopUp).click();

    }

    public String getPrice1(){
       return driver.findElement(Product1Price).getText();
    }

    public String getPrice2() {
        return driver.findElement(Product2Price).getText();

    }

    public String especifico1() {
        return  "$299.99";

    }

    public String especifico2() {
        return  "$1,009.00";

    }





}
